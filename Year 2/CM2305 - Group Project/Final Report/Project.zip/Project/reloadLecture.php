 <?php
 require_once('common.php');
if($_SESSION['loggedIn']){
    global $connection;

    //Check that the lecture exists and is open, otherwise send the student back

    if(isset($_POST['goToLecture']))
        $lecture = $_POST['goToLecture'];
    else
        $lecture = $_SESSION['currentRoom'];

    $sql = 'SELECT * FROM lecture WHERE shortcode = "'.$lecture.'" AND status="open"';
    $qry = mysqli_query($connection, $sql);
    if( mysqli_num_rows($qry) > 0){
        if(isset($_POST['goToLecture'])){
            $_SESSION['currentRoom'] = $_POST['goToLecture'];
        }

        if(!isset($room)){
            $sql = "SELECT * FROM lecture WHERE shortcode = '" . $_SESSION['currentRoom'] . "'";
            $qry = mysqli_query($connection, $sql);
            while($row = mysqli_fetch_assoc($qry)){
                $room = $row;
            }
        }
     ?>
 <div id="feature-container">
    <div id="feature-title">
        This lecture code is <?=$_SESSION['currentRoom'];?><br />
        The lecture status is <?=$room['status'];?>
    </div>
    
    <?php
    //See if there is a quiz and allow them to view it
    $sql = 'SELECT * FROM Questions where QuizID = "'.$_SESSION['currentRoom'].'"';
    $qry = mysqli_query($connection, $sql);
    $res = array();
    while($row = mysqli_fetch_assoc($qry)){
        $res[] = $row;
    }
    if(count($res) > 0){
        ?>
        <a onclick="loadPage('takeQuiz.php'); return false;">
        <div class="button">
            <p>
                <span style="color:#FC1E70">T</span>AKE <span style="color:#FC1E70">Q</span>UIZ
            </p>
        </div>
        </a>
        <?php
        }
        ?>

    <a onclick="loadPage('Forum.php'); return false;">
    <div class="button">
        <p>
            <span style="color:#FC1E70">V</span>IEW <span style="color:#FC1E70">F</span>ORUM
        </p>
    </div>
    </a>

    <a onclick="loadPage('studentControlPanel.php'); return false;">
    <div class="button">
        <p>
            <span style="color:#FC1E70">G</span>O <span style="color:#FC1E70">B</span>ACK
        </p>
    </div>
    </a>
</div>
<?php
}else{
    echo 'The room you have selected is either closed or does not exist';
    ?>
    <a onclick="loadPage('joinLecture.php'); return false;">
    <div class="button">
        <p>
            <span style="color:#FC1E70">G</span>O <span style="color:#FC1E70">B</span>ACK
        </p>
    </div>
    </a>
    <?php
}
?>
<?php

}else{
    echo 'You must be logged in to view this page';
}
?>