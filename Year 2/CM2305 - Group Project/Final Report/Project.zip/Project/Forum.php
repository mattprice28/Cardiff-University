 <?php
 require_once('common.php');
if($_SESSION['loggedIn']){
 
    if(isset($_POST['question'])){
        global $connection;
        $query= "INSERT INTO Forum (Question, shortcode) VALUES ('".mysqli_real_escape_string($connection, $_POST['question'])."', '".mysqli_real_escape_string($connection, $_SESSION['currentRoom'])."')";
        mysqli_query($connection, $query);
    }

    if(isset($_POST['qid'])){
        $update = "UPDATE Forum SET Votes = Votes + 1 WHERE ID= " . mysqli_real_escape_string($connection, $_POST['qid']);
        mysqli_query($connection, $update);
    }

    if(isset($_SESSION['currentRoom'])){
        $query = 'SELECT * FROM Forum WHERE shortcode = "' . $_SESSION['currentRoom'] .'" ORDER BY Votes DESC';
    }else{
        $query = 'SELECT * FROM Forum ORDER BY Votes DESC';
    }
 ?>
 <script>


setInterval(function(){
    $('#forum-reload').load('reloadForum.php');
}, 5000);


function validateForm() {
    var x = document.forms["myForm"]["fquestion"].value;
    if (x == null || x == "") {
        alert("Question must be filled out");
        return false;
    }else{
        var question = $('#myQuestion').val();
        loadingGif();   
        $.ajax({
           type: "POST",
           url: 'Forum.php',  
           data:"question="+question,
           success: function loadData(data){
                $('#feature-container').html(data);
               }
           });

    }
}
</script>

    <div id="feature-title">
Welcome to the Forum. Here you can ask your lecturer questions as the lecture is taken. Questions you would like to be answered can be voted using the like button<br />
<br />
Lecture room <?=$_SESSION['currentRoom'];?>
    </div>

<div id="askAQuestion">
<form name="myForm" >
Question: <input type="text" name="fquestion" id='myQuestion'>
<input type="submit" value="Submit" onclick="validateForm(); return false;">
</form>
</div>
<div id="forum-reload">
<?php
global $connection;
$result=mysqli_query($connection,$query);
$res = array();
while($row = @mysqli_fetch_assoc($result)){
    $res[] = $row;
  } 
  if(count($res) > 0){
    echo "<table id='questionTable'>";
    echo "<tr>";
    echo "<th>"."Question"."</th>";
    echo "<th>"."Votes"."</th>";
    echo "<th>"."Like"."</th>";
       
    echo "</tr>";
 
   foreach($res as $row){
        echo "<tr>";
        //echo "<br/>";        
        echo "<td>".$row["Question"]."</td>";
        echo "<td style='text-align:center;'>".$row["Votes"]."</td>";         
        echo '<td style="text-align:center;"><a onclick="upVote('.$row["ID"].'); return false;">Like</a></td>';
        echo "</tr>";
      }    
    echo "</table>";
  }else{
    echo '<p>No questions have been asked</p>';
  } 
?>
</div>
    <?php
    if($_SESSION['admin']){
    ?>
    <a onclick="loadPage('createLecture.php'); return false;">
    <div class="button">
        <p>
            <span style="color:#FC1E70">G</span>O <span style="color:#FC1E70">B</span>ACK
        </p>
    </div>
    </a>
<?php
}else{
    ?>
    <a onclick="loadPage('studentLecture.php'); return false;">
    <div class="button">
        <p>
            <span style="color:#FC1E70">G</span>O <span style="color:#FC1E70">B</span>ACK
        </p>
    </div>
    </a>
    <?php
}
}else{
    echo 'You must be logged in to view this page';
}
?>