<?php
require_once('common.php');
echo $_SESSION['loggedIn'];
echo 'test';
?>