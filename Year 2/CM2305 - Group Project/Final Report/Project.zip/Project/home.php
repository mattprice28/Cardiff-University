<?php
require_once('common.php');
?>
<!DOCTYPE html>
<html>
	<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/styles.css">
	<link rel="stylesheet" type="text/css" href="css/dropzone.css">
	<script src="scripts/dropzone.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
	<script type="text/javascript">
		
		$( document ).ready(function() {
			resizeMe();
		});

		function resizeMe(){
		 height = $(window).height();
		 width = $(window).prop("clientWidth");
		 $("html").css('width', width + "px");
		 $("html").css('height', height  + "px");
		 $("#main-container").css('min-height', height - 53 + "px");
		}

		function loadPage(pageToLoad){
		loadingGif();	
		$.ajax({
		   type: "POST",
		   url: pageToLoad,  
		   data:"",
		   success: function loadData(data){
				$('#feature-container').html(data);
			   }
		   });
		}

		function reLoadPage(pageToLoad){
		$.ajax({
		   type: "POST",
		   url: pageToLoad,  
		   data:"test=test",
		   success: function loadData(data){
				$('#feature-container').html(data);
			   }
		   });
		}

		function upVote(qid){
		$.ajax({
		   type: "POST",
		   url: "Forum.php",  
		   data:"qid="+qid,
		   success: function loadData(data){
				$('#feature-container').html(data);
			   }
		   });
		}

		function deleteLecture(qid){
		$.ajax({
		   type: "POST",
		   url: "oldLectures.php",  
		   data:"delLecture="+qid,
		   success: function loadData(data){
				$('#feature-container').html(data);
			   }
		   });
		}

		function joinLecture(){
			var lecture = $('#joinLectureCode').val();
			loadingGif();
			$.ajax({
			   type: "POST",
			   url: "studentLecture.php",  
			   data:"goToLecture="+lecture,
			   success: function loadData(data){
					$('#feature-container').html(data);
				   }
			   });
		}

		function goToLecture(qid){
			loadingGif();
			$.ajax({
			   type: "POST",
			   url: "createLecture.php",  
			   data:"goToLecture="+qid,
			   success: function loadData(data){
					$('#feature-container').html(data);
				   }
			   });
		}

		function changeStatus(status, room){
			loadingGif();
			$.ajax({
			   type: "POST",
			   url: "createLecture.php",  
			   data:"status="+status+"&room="+room,
			   success: function loadData(data){
					$('#feature-container').html(data);
				   }
			   });
		}
		



		$(document).on("click", '#submit-login', function(event) { 
		    var username = $('#username').val();
			var password = $('#password').val();
			loadingGif();	
			$.ajax({
			   type: "POST",
			   url: 'login.php',  
			   data:"username="+username+"&password="+password,
			   success: function loadData(data){
					$('#feature-container').html(data);
				   }
			   });
		});

		function loginForm(pageToLoad){
			var username = $('#username').val();
			var password = $('#password').val();
			loadingGif();	
			$.ajax({
			   type: "POST",
			   url: pageToLoad,  
			   data:"username="+username+"&password="+password,
			   success: function loadData(data){
					$('#feature-container').html(data);
				   }
			   });
		}

		function loadingGif(){
			code = "<div id='loading-gif'> <img src='images/loading.gif' /> </div>";
			$('#feature-container').html(code);
		}

		$(window).resize(function () {
		    if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
			 // some code..
			}else{
				resizeMe();
			}
		});
	</script>
	<link href='https://fonts.googleapis.com/css?family=Titillium+Web:400,300,600' rel='stylesheet' type='text/css'>
	<?php 
	$sql = 'SELECT * FROM styles';
    $qry = mysqli_query($connection, $sql);
    $styles = array();
    while($row = mysqli_fetch_assoc($qry)){
        $styles[] = $row;
    }
    if(count($styles) > 0){
    	foreach($styles as $s){
    	?>
	    	<style>
	    	<?php 
	    	if($s['id'] == 1 && $s['value']!='defualt')
	    		echo '#main-container{background-color:'.$s['value'].'!important;}';
	    	if($s['id'] == 2 && $s['value']!='defualt')
	    		echo '#footer{background-color:'.$s['value'].'!important;}';
	    	?>
			</style>
	    	<?php
    	}
    }
	?>
	
	</head>
	<body>
		<div id="main-container">
			<div id="title">
				<span style="color:#60D9F1">KNOWLEDGE</span><span style="color:#FC1E70;">BOMB</span>
			</div>
			<div id="strapline">
				Simply the best learning and education tool around!
			</div>
			<div id="feature-container">
				<div id="feature-title">
					Please log in with your Cardiff University username and password <br />
					If you aren't from Cardiff University then please register instead
				</div>
				<div class='login-container'>
				<form name="loginForm" action="" method="post">
					<input id='username' type="text" name="studentNumber" placeholder="Student Number">
					<input id='password' type="password" name="password" placeholder="Password">
				</form>	
				</div>
				<a onclick="return false;">
				<div class="button" id='submit-login'>
					<p>
						<span style="color:#FC1E70">L</span>OG <span style="color:#FC1E70">I</span>N
					</p>
				</div>
				</a>
				
			</div>
			
		</div>	
		<div id="footer">
			<a id='homeButton' onclick="loadPage('home-ajax.php'); return false;">
				<div id="home-icon">
					<img src="images/home-icon.png" />
				</div>
			</a>
			<div id="footer-logo">
				<a href="https://github.com/Kokushi/Group5" target="_blank"><img src="images/github.png" /></a>
			</div>
			<div id="footer-text">
				Fork us and contribute on Github!
			</div>
			<div id="preload-01"></div>
		</div>
	</body>
</html>