 <?php
 require_once('common.php');
if($_SESSION['loggedIn'] && $_SESSION['admin']){
 ?>
 
    <?php
    //Select all the questions for this room
    global $connection;
    $sql = 'SELECT * FROM Questions WHERE QuizID = "'.$_SESSION['currentRoom'].'" ORDER BY QuestionText ASC';
    $qry = mysqli_query($connection, $sql);
    while($row = mysqli_fetch_assoc($qry)){
        $questions[] = $row;
    }

   foreach($questions as $q){
        ?>
        <div class="questionHolder">
            <div class="questionTitle"><?=$q['QuestionText'];?></div>
            <div class="questionAnswer"><?=createQuestion($q, true);?></div>
        </div>
        <?php
   }
    ?>
    <a onclick="loadPage('createLecture.php'); return false;">
    <div class="button">
        <p>
            <span style="color:#FC1E70">G</span>O <span style="color:#FC1E70">B</span>ACK
        </p>
    </div>
    </a>
</div>
<?php
}else{
    echo 'You must be logged in to view this page';
}
?>