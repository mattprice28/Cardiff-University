 <?php
 require_once('common.php');
if($_SESSION['loggedIn']){
    global $connection;
    if(isset($_POST['status']) && isset($_POST['room'])){
        $sql = 'UPDATE lecture SET status = "'.$_POST['status'].'" WHERE shortcode = "'.$_POST['room'].'"';
        $qry = mysqli_query($connection, $sql);
    }
    if(isset($_POST['goToLecture'])){
        $_SESSION['currentRoom'] = $_POST['goToLecture'];
    }elseif(!empty($_GET['newLecture'])){
            //Create a shortcode for the lecture
            $confirm = false;
            
            while(!$confirm){
                $unique = substr(base64_encode(mt_rand()), 0, 8);

                $res = array();
                $sql = "SELECT * FROM lecture WHERE shortcode = '" . $unique . "'";
                $qry = mysqli_query($connection, $sql);
                while($row = mysqli_fetch_assoc($qry)){
                    $res[] = $row;
                }
                if(count($res) > 0)
                    $confirm = false;
                else{
                    $shortcode = $unique;
                    $confirm = true;
                    $sql = 'INSERT INTO lecture (shortcode, owner, created) VALUES ("' . $shortcode . '", "'.$_SESSION['uid'].'", "'.time().'")';
                    $qry = mysqli_query($connection, $sql);

                    $sql = "SELECT * FROM lecture WHERE shortcode = '" . $unique . "'";
                    $qry = mysqli_query($connection, $sql);
                    while($row = mysqli_fetch_assoc($qry)){
                        $room = $row;
                    }
                    $_SESSION['currentRoom'] = $room['shortcode'];
                }
            }
    }
    if(!isset($room)){
        $sql = "SELECT * FROM lecture WHERE shortcode = '" . $_SESSION['currentRoom'] . "'";
        $qry = mysqli_query($connection, $sql);
        while($row = mysqli_fetch_assoc($qry)){
            $room = $row;
        }
    }
 ?>
 <div id="feature-container">
    <div id="feature-title">
        This lecture code is <?=$_SESSION['currentRoom'];?><br />
        The lecture status is <?=$room['status'];?>
    </div>

    <?php
    if($room['status'] == 'closed'){
    ?>
        <a onclick="changeStatus('open', '<?=$room["shortcode"];?>'); return false;">
            <div class="button">
                <p>
                    <span style="color:#FC1E70">O</span>PEN <span style="color:#FC1E70">L</span>ECTURE
                </p>
            </div>
        </a>
    <?php
    }else{
        ?>
        <a onclick="changeStatus('closed', '<?=$room["shortcode"];?>'); return false;">
            <div class="button">
                <p>
                    <span style="color:#FC1E70">C</span>LOSE <span style="color:#FC1E70">L</span>ECTURE
                </p>
            </div>
        </a>
        <?php
    }
    ?>
    
    <?php
    //See if there is a quiz and allow them to view it
    $sql = 'SELECT * FROM Questions where QuizID = "'.$_SESSION['currentRoom'].'"';
    $qry = mysqli_query($connection, $sql);
    $res = array();
    while($row = mysqli_fetch_assoc($qry)){
        $res[] = $row;
    }
    if(count($res) > 0){
        ?>
         <a onclick="loadPage('viewQuiz.php'); return false;">
        <div class="button">
            <p>
                <span style="color:#FC1E70">V</span>IEW <span style="color:#FC1E70">Q</span>UIZ
            </p>
        </div>
        </a>
        <?php
    }else{
        ?>
        <a onclick="loadPage('createQuiz.php'); return false;">
        <div class="button">
            <p>
                <span style="color:#FC1E70">C</span>REATE <span style="color:#FC1E70">Q</span>UIZ
            </p>
        </div>
        </a>
        <?php
    }
    ?>

    <a onclick="loadPage('Forum.php'); return false;">
    <div class="button">
        <p>
            <span style="color:#FC1E70">V</span>IEW <span style="color:#FC1E70">F</span>ORUM
        </p>
    </div>
    </a>

    <a onclick="loadPage('lecturePanel.php'); return false;">
    <div class="button">
        <p>
            <span style="color:#FC1E70">G</span>O <span style="color:#FC1E70">B</span>ACK
        </p>
    </div>
    </a>
</div>
<?php
}else{
    echo 'You must be logged in to view this page';
}
?>