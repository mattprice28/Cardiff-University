<?php
require_once('common.php');
if($_SESSION['loggedIn']){
    $id=$_GET['id'];
    global $connection;

    $update = "UPDATE Forum SET Votes = Votes + 1 WHERE ID=$id";
    mysqli_query($connection, $update);
}
?>
