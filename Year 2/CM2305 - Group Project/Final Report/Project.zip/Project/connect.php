<?php

$servername = "csmysql.cs.cf.ac.uk";
$username = "c1419409";
$password = "whynd4";
$dbname = "c1419409";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

	if(isset($_POST['array'])) {
		$ID = $_POST['array'][0];
		$type = $_POST['array'][1];
		$question = $_POST['array'][2];
		$options = $_POST['array'][3];
		$answers = $_POST['array'][4];
	}
	
	$sql = "INSERT INTO `c1419409`.`Questions` (`QuestionID`, `QuestionType`, `QuestionText`, `Options`, `Answers`) VALUES ('$ID', '$type', '$question', '$options', '$answers');";

	if (mysqli_query($conn, $sql)) {
    echo "\n SUCCESS!!";
	} else {
	    echo "\n Error: " . $sql . "<br>" . mysqli_error($conn);
	}

mysqli_close($conn);
?>