 <?php
 require_once('common.php');

if($_SESSION['loggedIn'] && $_SESSION['admin']){
    global $connection;

    $sql = 'SELECT * FROM styles';
    $qry = mysqli_query($connection, $sql);
    while($row = mysqli_fetch_assoc($qry)){
        $styles[] = $row;
    }

    if(isset($_POST['reset'])){
         $sql = 'UPDATE styles SET value = "defualt"';
         $qry = mysqli_query($connection, $sql);
    }
    if(isset($_POST['styles'])){
        //print_r($_POST['styles']);
        $myS = rtrim($_POST['styles'], '$');
        $allS = explode('$', $myS);
        foreach($allS as $s){
            $vars = explode('!', $s);
            echo $vars[1];
            $sql = 'UPDATE styles SET value = "'.trim($vars[0], ',').'" WHERE id = "'.$vars[1].'"';
            $qry = mysqli_query($connection, $sql);
        }
    }
?>
<style>


/* colorpicker styles */
.colorpicker {
    background-color: #222222;
    border-radius: 5px 5px 5px 5px;
    box-shadow: 2px 2px 2px #444444;
    color: #FFFFFF;
    font-size: 12px;
    width: 320px;
    margin: 0 auto;
    clear: both;
    float: none;
    position: relative!important;
}
#picker {
    cursor: crosshair;
    float: left;
    margin: 10px;
    border: 0;
}
.controls {
    float: right;
    margin: 10px;
    display:none;
}
.controls > div {
    border: 1px solid #2F2F2F;
    margin-bottom: 5px;
    overflow: hidden;
    padding: 5px;
}
.controls label {
    float: left;
}
.controls > div input {
    background-color: #121212;
    border: 1px solid #2F2F2F;
    color: #DDDDDD;
    float: right;
    font-size: 10px;
    height: 14px;
    margin-left: 6px;
    text-align: center;
    text-transform: uppercase;
    width: 75px;
}
.preview {
    background: url("../images/select.png") repeat scroll center center transparent;
    border-radius: 3px;
    box-shadow: 2px 2px 2px #444444;
    cursor: pointer;
    height: 30px;
    width: 30px;
    margin:0 auto;
}

.wheelHolder{
    width: 320px;
    margin: 0 auto;
    clear: both;
    float: none;
    position: relative!important;
}
</style>
        Change the styles for the website<br /><br />

<?php
foreach($styles as $s){
    ?>
    <?=$s['name'];?><br />
    <br />
    <div class='colorHolder'>
        <div class="preview"><input type='hidden' class='theName' value='<?=$s["id"];?>' /></div>
    </div>
    <br />
    <?php
}
?>

<div class='wheelHolder'>
    <div class="colorpicker" style="display:none">
        <canvas id="picker" var="1" width="300" height="300"></canvas>
        <div class="controls">
            <div><label>R</label> <input type="text" id="rVal" /></div>
            <div><label>G</label> <input type="text" id="gVal" /></div>
            <div><label>B</label> <input type="text" id="bVal" /></div>
            <div><label>RGB</label> <input type="text" id="rgbVal" /></div>
            <div><label>HEX</label> <input type="text" id="hexVal" /></div>
        </div>
    </div>
</div>


<script src="js/script.js"></script>
<script type='text/javascript'>
function saveStyles(){
    var styles = new Array();
    $('.preview').each(function(){
       var style = $(this).css('background-color');
       var id = $(this).children('.theName').val();
       var combined = style + "!" + id +'$';
       styles.push(combined);
    });

    $.ajax({
       type: "POST",
       url: "styles.php",  
       data:"styles="+styles,
       success: function loadData(data){
            $('#feature-container').html(data);
           }
       });
        
}

function resetStyles(){
    $.ajax({
       type: "POST",
       url: "styles.php",  
       data:"reset=true",
       success: function loadData(data){
            $('#feature-container').html(data);
           }
       });
}
</script>

        
        <a onclick="saveStyles(); return false;">
            <div class="button">
                <p>
                    <span style="color:#FC1E70">S</span>AVE <span style="color:#FC1E70">S</span>TYLES
                </p>
            </div>
        </a>

        <a onclick="resetStyles(); return false;">
            <div class="button">
                <p>
                    <span style="color:#FC1E70">R</span>ESET <span style="color:#FC1E70">S</span>TYLES
                </p>
            </div>
        </a>

        <a onclick="loadPage('studentControlPanel.php'); return false;">
            <div class="button">
                <p>
                    <span style="color:#FC1E70">G</span>O <span style="color:#FC1E70">B</span>ACK
                </p>
            </div>
        </a>
        <?php
}else{
    echo 'You must be logged in to view this page';
}
?>