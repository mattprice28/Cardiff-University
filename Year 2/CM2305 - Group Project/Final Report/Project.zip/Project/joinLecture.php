 <?php
 require_once('common.php');
if($_SESSION['loggedIn']){
 ?>
    <div id="feature-title">
       Join a lecture <br />
       <br />
       Please enter the code to join the lecture below
    </div>

    <div id="joinLecturebutton">
        <form action="">
            <input type="text" placeholder="Lecture Code" id="joinLectureCode" />
        </form>
    </div>

    <a onclick="joinLecture(); return false;">
    <div class="button">
        <p>
            <span style="color:#FC1E70">J</span>OIN <span style="color:#FC1E70">L</span>ECTURE
        </p>
    </div>
    </a>
    
    <a onclick="loadPage('studentControlPanel.php'); return false;">
    <div class="button">
        <p>
            <span style="color:#FC1E70">G</span>O <span style="color:#FC1E70">B</span>ACK
        </p>
    </div>
    </a>
<?php
}else{
    echo 'You must be logged in to view this page';
}
?>