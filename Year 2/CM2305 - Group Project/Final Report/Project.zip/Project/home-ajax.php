<div id="feature-title">
	Please log in with your Cardiff University username and password <br />
	If you aren't from Cardiff University then please register instead
</div>
<div class='login-container'>
<form name="loginForm" action="" method="post">
	<input id='username' type="text" name="studentNumber" placeholder="Student Number">
	<input id='password' type="password" name="password" placeholder="Password">
</form>	
</div>
<a onclick="return false;">
<div class="button" id='submit-login'>
	<p>
		<span style="color:#FC1E70">L</span>OG <span style="color:#FC1E70">I</span>N
	</p>
</div>
</a>
<a onclick="return false;">
<div class="button">
	<p>
		<span style="color:#FC1E70">R</span>EGISTER
	</p>
</div>

</a>