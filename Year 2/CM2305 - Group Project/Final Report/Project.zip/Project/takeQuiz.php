 <?php
 require_once('common.php');

if($_SESSION['loggedIn']){
    global $connection;

    $sql = 'SELECT * FROM Questions WHERE QuizID = "'.$_SESSION['currentRoom'].'" ORDER BY QuestionText ASC';
    $qry = mysqli_query($connection, $sql);
    while($row = mysqli_fetch_assoc($qry)){
        $questions[] = $row;
    }

    $numberOfQuestions = count($questions);

    if(isset($_POST['submitted'])){
        $userAnswers = '';
        foreach($_POST as $key=>$p){
            if($key != 'submitted' && $key != 'qid'){
                $userAnswers = $userAnswers . $p . ',';
            }
        }
        $userAnswers = rtrim($userAnswers, ',');

        $sql = 'INSERT INTO answers (shortcode, user, answer, qid) VALUES ("'.$_SESSION['currentRoom'].'", "'.$_SESSION['uid'].'", "'.$userAnswers.'", "'.$_POST['qid'].'")';
        $qry = mysqli_query($connection, $sql);

        $_SESSION['currentQuestion'] += 1;
    }
    //Pull through the questions and store the current question number
    
    if(!$_SESSION['quizActive']){
        $_SESSION['currentQuestion'] = 0;
        $_SESSION['quizActive'] = true;
    }

    if($numberOfQuestions <= $_SESSION['currentQuestion']){
        ?>
        You have completed the test please view your results below or go back.
         <a onclick="loadPage('viewResults.php'); return false;">
        <div class="button" >
            <p>
                <span style="color:#FC1E70">V</span>IEW <span style="color:#FC1E70">R</span>ESULTS
            </p>
        </div>
        </a>

        <a onclick="loadPage('studentLecture.php'); return false;">
        <div class="button">
            <p>
                <span style="color:#FC1E70">G</span>O <span style="color:#FC1E70">B</span>ACK
            </p>
        </div>
        </a>
        <?php
    }else{
?>

     <script>
    function submitAnswerForm(){
        var form = $('#quizAnswers');
        loadingGif();
        $.ajax({
           type: "POST",
           url: "takeQuiz.php",  
           data:form.serialize(),
           success: function loadData(data){
                $('#feature-container').html(data);
               }
           });
        }
     </script>
    <div id="feature-title">
       Take the quiz! <br />
       <br />
        This lecture code is <?=$_SESSION['currentRoom'];?><br />
    </div>
    <form id="quizAnswers">
     <div class="questionHolder">
        <div class="questionTitle"><?=$questions[$_SESSION['currentQuestion']]['QuestionText'];?></div>
        <div class="questionAnswer"><?=createQuestion($questions[$_SESSION['currentQuestion']]);?></div>
        <input type="hidden" name="submitted" value="true" />
    </div>
    </form>
    
    <a onclick='submitAnswerForm(); return false;'>
    <div class="button" >
        <p>
            <span style="color:#FC1E70">S</span>UBMIT <span style="color:#FC1E70">A</span>NSWER
        </p>
    </div>
    </a>

    <a onclick="loadPage('studentLecture.php'); return false;">
    <div class="button">
        <p>
            <span style="color:#FC1E70">G</span>O <span style="color:#FC1E70">B</span>ACK
        </p>
    </div>
    </a>
<?php
}
}else{
    echo 'You must be logged in to view this page';
}
?>