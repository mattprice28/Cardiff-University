 <?php
 require_once('common.php');
if($_SESSION['loggedIn']){
 ?>
  <div id="feature-container">
    <div id="feature-title">
        User Control Panel
    </div>

    <a onclick="loadPage('joinLecture.php'); return false;">
    <div class="button">
        <p>
            <span style="color:#FC1E70">J</span>OIN <span style="color:#FC1E70">L</span>ECTURE
        </p>
    </div>
    </a>
     <?php
    if(isset($_SESSION['currentRoom'])){
        ?>
        <a onclick="loadPage('studentLecture.php'); return false;">
        <div class="button">
            <p>
                <span style="color:#FC1E70">C</span>URRENT <span style="color:#FC1E70">L</span>ECTURE
            </p>
        </div>
        </a>
        <?php
    }
    ?>
     <?php
    if($_SESSION['admin']){
        ?>
        <a onclick="loadPage('lecturePanel.php'); return false;">
        <div class="button">
            <p>
                <span style="color:#FC1E70">M</span>ANAGE <span style="color:#FC1E70">L</span>ECTURES
            </p>
        </div>
        </a>
        <?php
    }
    ?>

    <?php
    if($_SESSION['admin']){
        ?>
        <a onclick="loadPage('styles.php'); return false;">
        <div class="button">
            <p>
                <span style="color:#FC1E70">C</span>HANGE <span style="color:#FC1E70">S</span>TYLES
            </p>
        </div>
        </a>
        <?php
    }
    ?>


    <a onclick="loadPage('logout.php'); return false;">
    <div class="button">
        <p>
            <span style="color:#FC1E70">L</span>OG <span style="color:#FC1E70">O</span>UT
        </p>
    </div>
    </a>
    </div>
<?php
}else{
    echo 'You must be logged in to view this page';
}
?>