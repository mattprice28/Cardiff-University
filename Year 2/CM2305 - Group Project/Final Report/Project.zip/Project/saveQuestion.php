<?php
	require_once('common.php');
	global $connection;

	if(isset($_POST['array'])) {
		$ID = $_POST['array'][0];
		$type = $_POST['array'][1];
		$question = $_POST['array'][2];
		$options = $_POST['array'][3];
		$answers = $_POST['array'][4];
		$quizID = $_POST['array'][5];
	}
	
	$sql = "INSERT INTO `Questions` (`QuizID`, `QuestionType`, `QuestionText`, `Options`, `Answers`) VALUES ('$quizID', '$type', '$question', '$options', '$answers');";
	mysqli_query($connection, $sql);
	echo $sql;
?>