 <?php
 require_once('common.php');
if($_SESSION['loggedIn']){
    global $connection;
    if(isset($_POST['delLecture'])){
        $sql = 'UPDATE lecture SET status = "deleted" WHERE shortcode = "'.$_POST['delLecture'].'" AND owner = "' .$_SESSION['uid']. '"';
        $query = mysqli_query($connection, $sql);
    }
 ?>
    <div id="feature-title">
        Manage old lectures here
    </div>

    <?php
    global $connection;
    $sql = 'SELECT * FROM lecture WHERE owner = "'.$_SESSION['uid'].'" AND status != "deleted" ORDER BY created DESC';
    $qry = mysqli_query($connection, $sql);
    $res = array();

    while($row = @mysqli_fetch_assoc($qry)){
        $res[] = $row;
    }

    if(count($res) > 0){
        echo "<table id='questionTable'>";
        echo "<tr>";
        echo "<th>"."Lecture Code"."</th>";
        echo "<th>"."Status"."</th>";
        echo "<th>"."Created"."</th>";
        echo "<th>"."Remove"."</th>";
        echo "</tr>";
        foreach($res as $r){
            echo "<tr>";
            //echo "<br/>";        
            ?>
            <td><a onclick="goToLecture('<?=mysqli_real_escape_string($connection,$r["shortcode"]);?>'); return false;"><?=$r["shortcode"];?></a></td>
            <?php
            echo "<td style='text-align:center;'>".$r["status"]."</td>";         
            echo "<td style='text-align:center;'>".date("d/m/Y", $r["created"])."</td>";         
            ?>
            <td style="text-align:center;"><a onclick="deleteLecture('<?=mysqli_real_escape_string($connection,$r["shortcode"]);?>'); return false;">Remove</a></td>
            <?php
            echo "</tr>";
        }
        echo "</table>";
    }else{
        echo 'Sorry you have no past lectures';
    }
    ?>

    <a onclick="loadPage('lecturePanel.php'); return false;">
    <div class="button">
        <p>
            <span style="color:#FC1E70">G</span>O <span style="color:#FC1E70">B</span>ACK
        </p>
    </div>
    </a>
<?php
}else{
    echo 'You must be logged in to view this page';
}
?>