<?php
    require_once('common.php');
    if(isset($_POST['password'])){
        $error = false;
        $studentNumber = strtoupper($_POST['username']);
        $password = $_POST['password'];
        $debug = false;
        if($studentNumber == 'USER' && $password == 'password'){
            validateUser($studentNumber);
            include('studentControlPanel.php');
            $debug = true;
        }
        if($studentNumber == 'ADMIN' && $password == 'password'){
            validateUser($studentNumber);
            include('studentControlPanel.php');
            $debug = true;
        }

        //$ldap_server = "ldap.cs.cf.ac.uk";
        //$ldap_binddn = "dc=cs,dc=cardiff.ac.uk";
       if(!$debug){
            $ldap_server = "ldap-jccs.cf.ac.uk";
            $ldap_binddn = "t=uk-ac-jccs";
            $connect = ldap_connect("$ldap_server");
            ldap_set_option($connect, LDAP_OPT_PROTOCOL_VERSION, 3); 
            $r=ldap_bind($connect);
            
            $sr=ldap_search($connect, $ldap_binddn, "uid=$studentNumber", array("dn"));
            $info = ldap_first_entry($connect, $sr);
            if(@ldap_get_dn($connect, $info)){
                $trydn = ldap_get_dn($connect, $info);
                $connect = ldap_connect("ldaps://" . $ldap_server);
                ldap_set_option($connect, LDAP_OPT_PROTOCOL_VERSION, 3);

                if( $bind = @ldap_bind($connect, $trydn, $password) ) {
                    //Login successful show the controll pannel
                    validateUser($studentNumber);
                    include('studentControlPanel.php');
                }else{
                    $error = "Invalid password";
                }
            }
            else{
                $error = "Invalid Username or Password";
            } 
        }

        //If there are no errors add the user to the database if they aren't already added
        //If they are in then just chill
        //Will finish this later
        if(empty($error) && 1 == 2){
            global $connection;
            //Check if the user is in the database
            $sql = "INSERT INTO users ('username', 'password') VALUES (" . make_safe($studentNumber) . ", " . make_safe(md5($password)) .")";
            mysqli_query($connection, $sql);
        }
    }
    //Show the login again with the error
    if(!empty($error)){
        //print_r($_POST);
        ?>
        <div id="feature-container">
            <div id="feature-title">
                <?=$error;?> <br />
                If you aren't from Cardiff University then please register instead
            </div>
            <div class='login-container'>
            <form name="loginForm" action="" method="post">
                <input type="text" name="studentNumber" placeholder="Student Number">
                <input type="password" name="password" placeholder="Password">
            </form> 
            </div>
            <a onclick="return false;">
                <div class="button" id='submit-login'>
                    <p>
                        <span style="color:#FC1E70">L</span>OG <span style="color:#FC1E70">I</span>N
                    </p>
                </div>
                </a>
            <a onclick="loadPage('decrypt.php'); return false;">
            <div class="button">
                <p>
                    <span style="color:#FC1E70">R</span>EGISTER
                </p>
            </div>
            
            </a>
        </div>
        <?php
    }
?>