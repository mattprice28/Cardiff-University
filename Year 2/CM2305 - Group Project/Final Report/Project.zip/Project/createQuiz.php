<?php
 require_once('common.php');
if($_SESSION['loggedIn'] && $_SESSION['admin']){
 ?>
 <script>


	$(function(){
		var qNumber = 1; // number that is appended before each question
		var radioCount = 1; // identifies radio button questions
		var checkboxCount = 1; // identifies checkbox questions

		// Functions below deal with option addition for radio and check questions

		$( "#radiooption" ).click(function() {
			if (!($(".questionchoice")[0])){
    			$('#radioquestioninput').after('<label class="questionlabel"> <br/><br/>Answer:<br/> </label> <input type="text" class="questionchoice">');
			}
			else{
				$('.questionchoice').last().after('<label class="questionlabel"> <br/><br/>Answer:<br/> </label> <input type="text" class="questionchoice">');
			}

		});

		$( "#checkoption" ).click(function() {
			if (!($(".questionchoice")[0])){
    			$('#checkquestioninput').after('<label class="questionlabel"> <br/><br/>Answer:<br/> </label> <input type="text" class="questionchoice">');
			}
			else{
				$('.questionchoice').last().after('<label class="questionlabel"> <br/><br/>Answer:<br/> </label> <input type="text" class="questionchoice">');
			}

		});

		$( "#dropdownoption" ).click(function() {
			if (!($(".questionchoice")[0])){
    			$('#dropdownquestioninput').after('<label class="questionlabel"> <br/><br/>Answer:<br/> </label> <input type="text" class="questionchoice">');
			}
			else{
				$('.questionchoice').last().after('<label class="questionlabel"> <br/><br/>Answer:<br/> </label> <input type="text" class="questionchoice">');
			}

		});

		// Functions below do the question addition form showing/hiding

		$("#radiobuttonadd").click(function() {
			$('.questionlabel').remove(); // clears option labels
			$('.questionchoice').remove(); // clears options themselves
			$('#textform').css("display", "none");
			$('#checkform').css("display", "none");
			$('#fillinform').css("display", "none");
			$('#dropdownform').css("display", "none");
			$('#radioform').css("display", "block");
			$('#radioquestioninput').val(""); // clears question input field
			$('.questionchoice').val("");
		});

		$("#textbuttonadd").click(function() {
			$('#radioform').css("display", "none");
			$('#checkform').css("display", "none");
			$('#fillinform').css("display", "none");
			$('#dropdownform').css("display", "none");
			$('#textform').css("display", "block");
			$('#textquestioninput').val("");
		})

		$("#checkbuttonadd").click(function() {
			$('.questionlabel').remove();
			$('.questionchoice').remove();
			$('#radioform').css("display", "none");
			$('#textform').css("display", "none");
			$('#fillinform').css("display", "none");
			$('#dropdownform').css("display", "none");
			$('#checkform').css("display", "block");
			$('#checkquestioninput').val("");
			$('.questionchoice').val("");
		})

		$("#fillinbuttonadd").click(function() {
			$('#radioform').css("display", "none");
			$('#textform').css("display", "none");
			$('#checkform').css("display", "none");
			$('#dropdownform').css("display", "none");
			$('#fillinform').css("display", "block");
			$('#fillinquestioninput').val("");
		})

		$("#dropdownbuttonadd").click(function() {
			$('.questionlabel').remove();
			$('.questionchoice').remove();
			$('#radioform').css("display", "none");
			$('#textform').css("display", "none");
			$('#checkform').css("display", "none");
			$('#fillinform').css("display", "none");
			$('#dropdownform').css("display", "block");
			$('#dropdownquestioninput').val("");
			$('.questionchoice').val("");
		})

		// Functions below do the appending of stuff to the questionnaire

		$("#addradioquestion").click(function() {

			// String to hold the generated HTML

			var htmlString = "<div class='question' id ='radioquestion'>";

			// Validity checks for radio questions

			// if question text is empty
			if($( "#radioquestioninput" ).val()==""){
				alert("Please input question text.");
				return false;
			}

			if (!($(".questionchoice")[1])){
    			alert("Please input at least two options.");
				return false;
			}

			// if there's an empty option
			var x=0;
			$( ".questionchoice" ).each(function( index ) {

				var thisval = $(this).val();
				if(thisval==""){
					alert("Please input all options");
					x=1;
				}

			});
			if(x==1) return false;

			// actual adding of the question, starting with the question text
			var value = $( "#radioquestioninput" ).val();
			htmlString += "<h2>" + qNumber + ". " + value + "</h2>";
			qNumber++;

			var optionstring = "";
			// loop through each of the options and append them
			$( ".questionchoice" ).each(function( index ) {

				var thisval = $(this).val();
				htmlString += '<input type="radio" name = "radio' + radioCount + '" value="'+ thisval +'"> '+thisval+'<br/>';
				optionstring = optionstring + thisval + ",";
			});

			radioCount++;
			htmlString += '</div>';
			$("#questions").append(htmlString);
			//alert("Question added! \n Please fill in the answer on the form below!");

		});

		$("#addtextquestion").click(function() {

			// String to hold the generated HTML

			var htmlString = "<div class='question' id='textquestion'>";

			if($( "#textquestioninput" ).val()==""){
				alert("Please input question text.");
				return false;
			}
			var value = $( "#textquestioninput" ).val();

			htmlString += "<h2>" + qNumber + ". " + value + "<br> <input type='text' name = 'text'> <br/> </h2>";
			qNumber++;

			$("#questions").append(htmlString);
			//alert("Question added! \n Please fill in the answer on the form below!");

		});

		$("#addcheckquestion").click(function() {

			// String to hold the generated HTML
			var htmlString = "<div class='question' id ='checkboxquestion'>";

			// Validity checks for checkbox questions

			// if question text is empty
			if($( "#checkquestioninput" ).val()==""){
				alert("Please input question text.");
				return false;
			}

			if (!($(".questionchoice")[1])){
    			alert("Please input at least two options.");
				return false;
			}

			// if there's an empty option
			var x=0;
			$( ".questionchoice" ).each(function( index ) {

				var thisval = $(this).val();
				if(thisval==""){
					alert("Please input all options");
					x=1;
				}
			});
			if(x==1) return false;

			var value = $( "#checkquestioninput" ).val();
			htmlString += "<h2>" + qNumber + ". " + value + "</h2>";
			qNumber++;

			var optionstring = "";
			// loop through each of the options and append them
			$( ".questionchoice" ).each(function( index ) {
				var thisval = $(this).val();
				htmlString += '<input type="checkbox" name = "checkbox'+checkboxCount+'" value="'+ thisval +'"> '+thisval+'<br/>';
				optionstring = optionstring + thisval + ",";
			});
			checkboxCount++;

			htmlString += "</div>";

			$('#questions').append(htmlString);
			//alert("Question added! \n Please fill in the answer on the form below!");

		});


		$("#addfillinquestion").click(function() {

			// String to hold the generated HTML
			var htmlString = "<div class='question' id='fillinquestion'>";

			if($( "#fillinquestioninput" ).val()==""){
				alert("Please input question text.");
				return false;
			}
			var value = $("#fillinquestioninput").val();
			htmlString += "<p hidden>" + qNumber + "." + value + "</p>";
			var val_save = value;
			for(i=20; i>0; i--){
				var pattern = new RegExp("_\\{" + i + "\\}");
				value = value.replace(pattern, '<input type="text" id = "fillinbox" size = "'+i+'">');
			}
			//value = value.replace(/_{3}/g, '<input type="text" id = "fillinbox" size = "5">');
			htmlString += "<h2>" + qNumber + ".</h2>" + "<p>" + value + "</p>";
			qNumber++;

			htmlString += "</div>";
			$("#questions").append(htmlString);
			//alert("Question added! \n Please fill in the answer on the form below!");

		});

		$("#adddropdownquestion").click(function() {

			// String to hold the generated HTML
			var htmlString = "<div class='question' id ='dropdownquestion'>";

			// Validity checks for dropdown questions

			// if question text is empty
			if($( "#dropdownquestioninput" ).val()==""){
				alert("Please input question text.");
				return false;
			}

			if (!($(".questionchoice")[1])){
    			alert("Please input at least two options.");
				return false;
			}

			// if there's an empty option
			var x=0;
			$( ".questionchoice" ).each(function( index ) {

				var thisval = $(this).val();
				if(thisval==""){
					alert("Please input all options");
					x=1;
				}
			});
			if(x==1) return false;

			var value = $( "#dropdownquestioninput" ).val();
			htmlString += "<h2>" + qNumber + ". " + value + "</h2>";
			qNumber++;

			var optionstring = "";
			htmlString += '<select>';
			$( ".questionchoice" ).each(function( index ) {
				var thisval = $(this).val();
				optionstring = optionstring + thisval + ",";
				htmlString += "<option value='" + thisval + "'>" + thisval + "</option>";
			});

			htmlString += "</select></div>";
			$("#questions").append(htmlString);
			//alert("Question added! \n Please fill in the answer on the form below!");
		});

	$( "#createquestionnaire" ).click(function() {
		// check if there are any questions at all
		if(typeof document.getElementById("questions")[0]=="undefined"){
			alert("Please add questions first!");
		}
		// check if any questions don't have answers given to them
		else{
			// first check for unanswered questions
			var isAnswered = false;
			var outputString = "";
			$(".question").each(function(index) {
				if(this.id == "radioquestion" || this.id == "checkboxquestion") {
					isAnswered=false; // handles resetting of the variable after each question
					$(this).find("input").each(function(index) {
						if($(this).is(':checked')) { isAnswered=true; }
					});
					if(isAnswered==false){
						questionNumber = index+1;
						if(outputString!=""){
							outputString = outputString.concat("\n"); // newline for proper formatting
						}
						outputString = outputString.concat("Question " + questionNumber + " is still unanswered!");
					}
				}
				else if(this.id == "textquestion"){
					answerText = $(this).find("input");
					if(answerText.val()==""){
						questionNumber = index+1;
						if(outputString!=""){
							outputString = outputString.concat("\n");
						}
						outputString = outputString.concat("Question " + questionNumber + " is still unanswered!");
						isAnswered=false;
					}
					else{
						isAnswered=true;
					}
				}
				else if(this.id == "fillinquestion"){
					$(this).find("input").each(function(index) {
						if($(this).val()==""){
							questionNumber = index+1;
							if(outputString!=""){
								outputString = outputString.concat("\n");
							}
							outputString = outputString.concat("Question " + questionNumber + " is still unanswered!");
							isAnswered=false;
						}
						else{
							isAnswered=true;
						}
					});
				}
				else if(this.id=="dropdownquestion"){
					isAnswered=true;
				}
			});
			// if all question are answered, get question information
			if(isAnswered==true){
				$(".question").each(function(index) {
					//alert('Question type: ' + this.id);
					if(this.id == "radioquestion" || this.id == "checkboxquestion") {
						questionText = $(this).find("h2").text();
						//alert("Question text: " + questionText);

						var options = "";
						var delim = "";
						$(this).find("input").each(function(index) {
							//alert('Option ' + index + ' : ' + $(this).val());
							options = options.concat(delim);
							options = options.concat($(this).val());
							delim=", ";
						});
						var answers = "";
						delim = "";
						$(this).find("input").each(function(index) {
							if($(this).is(':checked')) {
								//alert($(this).val() + " is a correct answer.");
								answers = answers.concat(delim);
								answers = answers.concat($(this).val());
								delim=", ";
							}
						});
						if(this.id=="radioquestion"){
							var array = [index+1, "radio", questionText, options, answers, "<?=$_SESSION['currentRoom'];?>"];
						}
						else{
							var array = [index+1, "checkbox", questionText, options, answers, "<?=$_SESSION['currentRoom'];?>"];
						}
						$.post('saveQuestion.php', {array: array}, function(data) {
						});

					}
					else if(this.id == "textquestion"){
						questionText = $(this).find("h2").text();
						//alert("Question text: " + questionText);
						answerText = $(this).find("input");
						//alert('Answer is: ' + answerText.val());
						var array = [index+1, "text", questionText, "NULL", answerText.val(), "<?=$_SESSION['currentRoom'];?>"];
						$.post('saveQuestion.php', {array: array}, function(data) {
						});
					}
					else if(this.id == "fillinquestion"){
						questionText = $(this).find("p:first").text();
						//alert("Question text: " + questionText);
						var answers = "";
						delim = "";
						$(this).find("input").each(function(index) {
							//alert('Answer: ' + index + ' : ' + $(this).val());
							answers = answers.concat(delim);
							answers = answers.concat($(this).val());
							delim=", ";
						});
						var array = [index+1, "fillin", questionText, "NULL", answers, "<?=$_SESSION['currentRoom'];?>"];
						$.post('saveQuestion.php', {array: array}, function(data) {
						});
					}
					else if(this.id == "dropdownquestion"){
						questionText = $(this).find("h2").text();
						//alert("Question text: " + questionText);
						var options = "";
						var delim = "";
						$(this).find("option").each(function(index) {
							//alert('Option ' + index + ' : ' + $(this).val());
							options = options.concat(delim);
							options = options.concat($(this).val());
							delim=", ";
						});
						var answers = "";
						var delim = "";
						$(this).find("option").each(function(index) {
							if($(this).is(':checked')) {
								//alert($(this).val() + " is a correct answer.");
								answers = answers.concat(delim);
								answers = answers.concat($(this).val());
								delim=", ";
							}
						});
						var array = [index+1, "dropdown", questionText, options, answers, "<?=$_SESSION['currentRoom'];?>"];
						$.post('saveQuestion.php', {array: array}, function(data) {
						});
					}
				});

				loadPage('createLecture.php');
			}
			else{
				alert(outputString);
			}
		}
	});

	});


</script>
<div id="createQuiz">
	<h2>Create a questionnaire</h2>
	<h3>Add question</h3>

	<h4><a href="#" id="radiobuttonadd">Radio button</a> &nbsp
	<a href='#' id="textbuttonadd">Textbox</a> &nbsp
	<a href='#' id="checkbuttonadd">Checkbox</a> &nbsp
	<a href='#' id="fillinbuttonadd">Fill in the blanks</a> &nbsp
	<a href='#' id="dropdownbuttonadd">Dropdown</a></h4>

	<div style="display:none;" id="radioform">
		<form>
			Radio button question text: <input type="text" id="radioquestioninput">
			<form>

			</form>

			<button type="button" id="radiooption">Add answer</button>
			<button type="button" id="addradioquestion">Add question</button>
		</form>
	</div>

	<div style="display:none;" id="textform">
		<form>
			Textbox question text: <input type="text" id="textquestioninput">
			<button type="button" id="addtextquestion">Add question</button>
		</form>
	</div>

	<div style="display:none;" id="checkform">
		<form>
			Checkbox question text: <input type="text" id="checkquestioninput">
			<form>

			</form>
			<button type="button" id="checkoption">Add answer</button>
			<button type="button" id="addcheckquestion">Add question</button>
		</form>
	</div>

	<div style="display:none;" id="fillinform">
		<form>
			Fill in the blanks question text (To indicate blanks use the format "_{boxlength}"): <br>
			<textarea id = "fillinquestioninput" rows = "6" cols = "55" style="resize:none;"> </textarea> <br>
			<button type="button" id="addfillinquestion">Add question</button>
		</form>
	</div>

	<div style="display:none;" id="dropdownform">
		<form>
			Dropdown question text: <input type="text" id="dropdownquestioninput">
			<form>

			</form>
			<button type="button" id="dropdownoption">Add answer</button>
			<button type="button" id="adddropdownquestion">Add question</button>
		</form>
	</div>

	<div>
		<form id = "questions">

		</form>
	</div>
	<h4> <button type="button" id="createquestionnaire"> Create questionnaire </button> </h4>
<div>
 <?php
}else{
	echo 'You must be logged in and an Admin to do this';
}
 ?>