<?php
session_start();

//Connect to the mysql server
$connection = mysqli_connect('csmysql.cs.cf.ac.uk', 'group5.2015', 'flicVol6');
    if (!$connection) {
        die('Could not connect: ' . mysql_error());
    }else{
		mysqli_select_db($connection, 'group5_2015');
	}

//Function is used to strip quotes and any unwanted characters that can be harmful to SQL commands
//A very quick SQL injection prevention method - a small security increase
function make_safe( $value, $force_quotes = false )
	{
		global $connection;
		if( is_numeric( $value ) && !$force_quotes )
			return $value;

		if( get_magic_quotes_gpc() )
			$value = stripslashes( $value );

	    return "'".mysqli_real_escape_string( $connection, $value )."'";
	}

//Runs a query and returns all data from that table unless a query is added
function get_data($sql){
	$connection = mysqli_connect('csmysql.cs.cf.ac.uk', 'group5.2015', 'flicVol6');
    if (!$connection) {
        die('Could not connect: ' . mysql_error());
    }else{
		mysqli_select_db($connection, 'group5_2015');
	}
	//Run the query
	$qry = mysqli_query($connection, $sql);
	while($row = mysqli_fetch_assoc($qry)){
		$res[] = $row;
	}
	//Return the query
	return $res;
}

//Checks to see if that user is in the database already
//If not it adds them assuming they can log in via ldap
function validateUser($username){
	global $connection;
	$res = null;
	$sql = "SELECT * FROM users WHERE username = '" . $username ."'";
	$qry = mysqli_query($connection, $sql);
	while($row = mysqli_fetch_assoc($qry)){
		$res = $row;
	}
	if($res != null){
		$_SESSION['uid'] = $res['id'];
		$_SESSION['loggedIn'] = true;
		if($res['admin'] == 1)
			$_SESSION['admin'] = true;
		else
			$_SESSION['admin'] = false;
	}else{
		$sql = 'INSERT INTO users (username) VALUES ("'.$username.'")';
		$qry = mysqli_query($connection, $sql);

		//Now grab their newly added uid
		$res = null;
		$sql = "SELECT * FROM users WHERE username = '" . $username . "'";
		$qry = mysqli_query($connection, $sql);
		while($row = mysqli_fetch_assoc($qry)){
			$res = $row;
		}
		$_SESSION['uid'] = $res['id'];
		$_SESSION['loggedIn'] = true;
		$_SESSION['admin'] = false;
	}
	$_SESSION['currentQuestion'] = 0;
    $_SESSION['quizActive'] = false;
}

//This function creates the question based on the array passed from the DB
function createQuestion($array, $showAnswers=false){
	$question = '';

	//Prepare a checkbox question
	if($array['QuestionType'] == 'checkbox'){
		$options = explode(',', $array['Options']);
		$counter = 0;
		foreach($options as $o){
			$checked = '';
			$answers = explode(',', $array['Answers']);
			if(in_array($o, $answers)){
				$checked = 'checked="checked"';
			}
			if($showAnswers)
				$question = $question . '<input type="checkbox" '.$checked.' name="'.$array['QuestionID'] . $counter.'" value="'.$o.'">' . $o . '<br />';
			else
				$question = $question . '<input type="checkbox" name="'.$array['QuestionID']. $counter.'" value="'.$o.'">' . $o . '<br />';

			$counter++;
		}
	}

	//Prepare a dropdown question
	if($array['QuestionType'] == 'dropdown'){
		$question = $question . '<select name="'.$array['QuestionID'].'">';
		$options = explode(',', $array['Options']);
		foreach($options as $o){
			$checked = '';
			$answers = explode(',', $array['Answers']);
			if(in_array($o, $answers)){
				$checked = 'selected="selected"';
			}
			if($showAnswers)
				$question = $question . '<option '.$checked.' name="'.$array['QuestionID'].'" value="'.$o.'">' . $o . '</option>';
			else
				$question = $question . '<option name="'.$array['QuestionID'].'" value="'.$o.'">' . $o . '</option>';
		}
		$question = $question . '</select>';
	}

	//Prepare a radio question
	if($array['QuestionType'] == 'radio'){
		$options = explode(',', $array['Options']);
		foreach($options as $o){
			$checked = '';
			$answers = explode(',', $array['Answers']);
			if(in_array($o, $answers)){
				$checked = 'checked="checked"';
			}
			if($showAnswers)
				$question = $question . '<input type="radio" '.$checked.' name="'.$array['QuestionID'].'" value="'.$o.'">' . $o . '<br />';
			else
				$question = $question . '<input type="radio" name="'.$array['QuestionID'].'" value="'.$o.'">' . $o . '<br />';
		}
	}

	//Prepare a text question
	if($array['QuestionType'] == 'text'){
		if($showAnswers)
			$question = $question . '<input type="text" name="'.$array['QuestionID'].'" value="'.$array['Answers'].'" /><br />';	
		else
			$question = $question . '<input type="text" name="'.$array['QuestionID'].'" /><br />';	
	}

	//Prepare a fill in the blanks question
	if($array['QuestionType'] == 'fillin'){
		$pattern = '/_{([0-9])*}/';
		$text = $array['QuestionText'];
		preg_match_all($pattern, $array['QuestionText'], $matches, PREG_PATTERN_ORDER);
		//print_r($matches);
		$m = $matches[0];
		foreach($m as $mat){
			$vals = preg_replace("/[^0-9]/","",$m);
		}

		$counter = 0;
		$answers = explode(',', $array['Answers']);
		foreach($vals as $v){
			if($showAnswers)
				$input = '<input type="text" size="'.$v.'" name="'.$array['QuestionID'].$counter.'" value="'.$answers[$counter].'" />';
			else
				$input = '<input type="text" name="'.$array['QuestionID'].$counter.'" size="'.$v.'"  />';
			$replace = '_{' . $v . '}';
			$count = 1;
			$text = str_replace($replace, $input, $text, $count);
			$counter++;
		}
		
		$question = $text . '<br />';
		//$question = $question . '<input type="text" name="'.$array['QuestionID'].'" value="'.$array['Answers'].'" /><br />';

		
	}

	$question = $question . '<input type="hidden" name="qid" value="'.$array['QuestionID'].'" />';
	echo $question;
}

?>