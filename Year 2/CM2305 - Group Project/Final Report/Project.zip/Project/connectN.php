<?php
$con = mysqli_connect("csmysql.cs.cf.ac.uk", "c1339817", "vavif7","c1339817");
?>