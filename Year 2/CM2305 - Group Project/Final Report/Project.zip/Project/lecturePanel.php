 <?php
 require_once('common.php');
if($_SESSION['loggedIn'] && $_SESSION['admin']){
 ?>
    <div id="feature-title">
        Create and manage your lectures here
        <?php
        if(!empty($_SESSION['currentRoom'])){
            ?>
            <br />
            <br />
            Your current lecture is <?=$_SESSION['currentRoom'];?>
            <?php
        }
        ?>
    </div>

    <a onclick="loadPage('createLecture.php?newLecture=true'); return false;">
    <div class="button">
        <p>
            <span style="color:#FC1E70">C</span>REATE <span style="color:#FC1E70">L</span>ECTURE
        </p>
    </div>
    </a>
    <?php
    if(!empty($_SESSION['currentRoom'])){
        ?>
        <a onclick="loadPage('createLecture.php'); return false;">
        <div class="button">
            <p>
                <span style="color:#FC1E70">E</span>DIT <span style="color:#FC1E70">L</span>ECTURE
            </p>
        </div>
        </a>
        <?php
    }
    ?>

    <a onclick="loadPage('oldLectures.php'); return false;">
    <div class="button">
        <p>
            <span style="color:#FC1E70">O</span>LD <span style="color:#FC1E70">L</span>ECTURES
        </p>
    </div>
    </a>

    <a onclick="loadPage('studentControlPanel.php'); return false;">
    <div class="button">
        <p>
            <span style="color:#FC1E70">G</span>O <span style="color:#FC1E70">B</span>ACK
        </p>
    </div>
    </a>
<?php
}else{
    echo 'You must be logged in to view this page';
}
?>