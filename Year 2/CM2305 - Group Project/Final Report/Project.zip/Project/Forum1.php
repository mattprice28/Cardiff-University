<?php
require_once('common.php');
global $connection;

$query= "INSERT INTO Forum (Question) VALUES ('$_POST[fquestion]')";
mysqli_query($connection, $query) or die ("Could not insert rows because " .mysqli_error($connection));
?>