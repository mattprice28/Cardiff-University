 <?php
 require_once('common.php');

if($_SESSION['loggedIn']){
    global $connection;

    $sql = 'SELECT * FROM answers WHERE shortcode = "'.$_SESSION['currentRoom'].'" AND user = "'.$_SESSION['uid'].'" ORDER BY id ASC';
    $qry = mysqli_query($connection, $sql);
    while($row = mysqli_fetch_assoc($qry)){
        $answers[] = $row;
    }

    $sql = 'SELECT * FROM Questions WHERE QuizID = "'.$_SESSION['currentRoom'].'" ORDER BY QuestionText ASC';
    $qry = mysqli_query($connection, $sql);
    while($row = mysqli_fetch_assoc($qry)){
        $questions[] = $row;
    }

    $counter = 0;
    $score = 0;
    $maxScore = count($questions);
    foreach($answers as $a){
        $curA = strtolower(str_replace(' ', '', $a['answer']));
        $curQ = strtolower(str_replace(' ', '', $questions[$counter]['Answers']));
        if($curA == $curQ)
            $score++;
        $counter++;
    }

        ?>
        You scored <?=$score;?>/<?=$maxScore;?> or <?=($score/$maxScore)*100;?>% <br />
        <br />
        The correct answers are below

        <?php
        foreach($questions as $q){
        ?>
        <div class="questionHolder">
            <div class="questionTitle"><?=$q['QuestionText'];?></div>
            <div class="questionAnswer"><?=createQuestion($q, true);?></div>
        </div>
        <?php
        }
        ?>

        <a onclick="loadPage('studentLecture.php'); return false;">
        <div class="button">
            <p>
                <span style="color:#FC1E70">G</span>O <span style="color:#FC1E70">B</span>ACK
            </p>
        </div>
        </a>
        <?php
}else{
    echo 'You must be logged in to view this page';
}
?>