<?php

$servername = "csmysql.cs.cf.ac.uk";
$username = "c1419409";
$password = "whynd4";
$dbname = "c1419409";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
	
	$sql = "DELETE FROM `c1419409`.`Questions`;";

	if (mysqli_query($conn, $sql)) {
    echo "\n SUCCESS!!";
	} else {
	    echo "\n Error: " . $sql . "<br>" . mysqli_error($conn);
	}

mysqli_close($conn);
?>