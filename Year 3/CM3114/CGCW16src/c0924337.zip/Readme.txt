CGCW01 has has all translation and scale functions fully implemented

CGCW02 has both shapes, the sphere and cylinder, in the correct orientation and position and with the cylinder set to a different material

CGCW03 Generates a multicoloured cube (copied directly from the lab code) I was not able to implement my own frag and vert files or apply the .jpg file